data/ —— 番茄签名服务所需的官方库（自备文件包）
=================================================

放置位置（三选一，服务会按顺序查找）:
  1) 环境变量 FQ_DATA_DIR 指向本目录
  2) 【推荐】与服务端 jar / docker-compose.yaml 同级的 data/ 目录
  3) 当前工作目录下的 data/

文件说明:
  libmetasec_ml.so    必需  签名核心库
  libc++_shared.so    必需  C++ 运行时（arm64-v8a）
  base.apk            占位  纯签名服务不需要真 APK，空文件即可
  ms_16777218.bin     可选  运行时证书文件，缺失时部分流程可能失败

Docker 部署:
  compose.yaml 里挂载  - ./data:/app/data:ro
  启动日志应打印:      [IdleFQ] 外部数据目录: /app/data

直接跑 jar:
  java -jar fq_download.jar serve 8090     # 在含 data/ 的目录下执行

校验:
  md5sum -c md5.txt

⚠️ 合规提醒:
  本包内的 .so / .bin 均为【官方版权物】，请仅在你已合法持有的范围内使用，
  不要公开分发（公开仓库/Release 会有 DMCA 风险）。
